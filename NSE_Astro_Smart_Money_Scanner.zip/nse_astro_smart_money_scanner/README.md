# NSE Astro + Smart Money Scanner

Python/GitHub Actions project for a scheduled **research watchlist** of NSE F&O stocks.
It ranks up to 3 bullish and 3 bearish candidates using 5-minute technical signals and
adds Moon Nakshatra / planetary Hora context. It does **not** place orders.

## Important data limits

- This starter uses `yfinance` Yahoo Finance symbols (`SYMBOL.NS`) for public market
  candles. It is not an official NSE feed and availability, delay, completeness and
  terms can change. Do not assume real-time prices.
- The script deliberately does **not** scrape NSE website endpoints. NSE's published
  terms prohibit systematic automated collection without express written consent.
- Futures OI and option-chain confirmation are reported as **unavailable / unconfirmed**
  in this free-data starter. Do not treat them as confirmed. Connect a permitted,
  licensed feed before relying on them.
- Yahoo Finance 5-minute history is limited and may be missing for some symbols.
- Astrology/Hora/Nakshatra are experimental annotations, not scientifically validated
  predictors. Never trade on them alone.
- GitHub Actions schedules are best-effort, can be delayed, and do not run as a guaranteed
  real-time engine. The schedule uses UTC and the script checks India market hours.
- This is educational software, not investment advice. Verify data and all signals yourself.

## Included image mappings

- Krittika -> Bullish Engulfing; Three White Soldiers
- Rohini -> Inside Bar; Rising Three
- Mrigashira -> Spinning Top; Piercing Line

Only the three mappings visible in the provided image are included. Patterns are calculated
from recent candles; the Nakshatra mapping is shown as context, not as proof of causation.

## Files

- `scanner.py` - data retrieval, indicators, astronomy, ranking and report generation
- `symbols.txt` - starter universe of liquid F&O names; edit as desired
- `requirements.txt` - Python dependencies
- `.github/workflows/scan.yml` - scheduled GitHub Actions workflow
- `reports/` - generated Markdown/CSV reports

## Setup on Android

1. Open GitHub in Chrome and sign in.
2. Create a repository named `NSE_Astro_Smart_Money_Scanner`.
3. Upload the files from this ZIP, preserving the folder path `.github/workflows/scan.yml`.
   Easiest: download/unzip on a computer, or upload the individual files using GitHub's
   **Add file -> Create new file** page on Android.
4. Ensure the repository's default branch is `main`.
5. Go to **Settings -> Actions -> General** and allow actions if they are disabled.
6. Go to **Actions**, select **NSE Astro + Smart Money Scan**, and choose **Run workflow**
   for a manual test.
7. Open the run and inspect its logs and uploaded artifact. On a successful scheduled run,
   the workflow commits the latest report into `reports/scan_latest.md` and
   `reports/scan_latest.csv`.
8. In a public repository, GitHub may disable scheduled workflows after 60 days without
   repository activity. Check Actions periodically.

## Market hours

The workflow is scheduled every 5 minutes across the approximate NSE weekday window
(09:15–15:30 Asia/Kolkata; UTC cron entries). It skips Saturday/Sunday and checks the local
clock, but this starter does not have an official exchange-holiday calendar. On exchange holidays, it may run and produce an
empty/limited scan unless you add the holiday date to `HOLIDAYS` in `scanner.py`.

## Scoring

Technical score (maximum 85 points):
- Price/VWAP + ORB: 25
- EMA trend: 15
- RSI: 10
- ADX: 10
- Relative volume: 15
- Candlestick confirmation: 10

Astronomy context is displayed separately and is not allowed to override technical direction.
The scanner ranks candidates by technical score and requires a minimum score of 50.

## Troubleshooting

- `No data`: Yahoo Finance may not have recent 5-minute bars for that ticker. Check the
  symbol, retry later, or configure a permitted data provider.
- Missing OI / options: expected in this starter. A licensed/authorized data feed is needed.
- GitHub scheduled run absent: check the default branch, Actions permissions, and whether
  the repository has been inactive for 60 days.
