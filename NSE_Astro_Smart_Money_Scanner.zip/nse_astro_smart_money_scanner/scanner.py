from __future__ import annotations

import math
import os
from datetime import datetime, date, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd
import yfinance as yf
import swisseph as swe

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
SYMBOL_FILE = ROOT / "symbols.txt"
IST = ZoneInfo("Asia/Kolkata")
MIN_SCORE = 50

# Add exchange holidays as ISO dates, e.g. "2026-10-20".
HOLIDAYS: set[str] = set()

NAKSHATRA_NAMES = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni",
    "Uttara Phalguni", "Hasta", "Chitra", "Swati", "Vishakha",
    "Anuradha", "Jyeshtha", "Mula", "Purva Ashadha", "Uttara Ashadha",
    "Shravana", "Dhanishta", "Shatabhisha", "Purva Bhadrapada",
    "Uttara Bhadrapada", "Revati",
]
NAKSHATRA_PATTERNS = {
    "Krittika": ["Bullish Engulfing", "Three White Soldiers"],
    "Rohini": ["Inside Bar", "Rising Three"],
    "Mrigashira": ["Spinning Top", "Piercing Line"],
}
# Traditional weekday Hora lords, repeating in Chaldean order.
PLANET_ORDER = ["Saturn", "Jupiter", "Mars", "Sun", "Venus", "Mercury", "Moon"]
DAY_LORDS = {
    0: "Moon", 1: "Mars", 2: "Mercury", 3: "Jupiter",
    4: "Venus", 5: "Saturn", 6: "Sun"
}
# Approximate Sun time only used as an informational Hora label; sunrise/sunset are
# calculated with Swiss Ephemeris. If that fails, Hora is marked unavailable.

def now_ist() -> datetime:
    return datetime.now(IST)

def market_is_open_window(now: datetime) -> bool:
    if now.weekday() >= 5 or now.date().isoformat() in HOLIDAYS:
        return False
    t = now.time()
    return time(9, 15) <= t <= time(15, 30)

def load_symbols() -> list[str]:
    if not SYMBOL_FILE.exists():
        return ["RELIANCE", "HDFCBANK", "ICICIBANK", "SBIN", "INFY", "TCS"]
    out = []
    for line in SYMBOL_FILE.read_text().splitlines():
        s = line.split("#", 1)[0].strip()
        if s:
            out.append(s)
    return list(dict.fromkeys(out))

def get_moon_nakshatra(dt: datetime) -> tuple[str, float]:
    """Sidereal Moon longitude using Swiss Ephemeris Lahiri ayanamsa."""
    utc = dt.astimezone(timezone.utc)
    jd = swe.julday(utc.year, utc.month, utc.day,
                    utc.hour + utc.minute / 60 + utc.second / 3600)
    swe.set_sid_mode(swe.SIDM_LAHIRI)
    result, _ = swe.calc_ut(jd, swe.MOON, swe.FLG_SWIEPH | swe.FLG_SIDEREAL)
    lon = result[0] % 360
    idx = int(lon / (360 / 27))
    return NAKSHATRA_NAMES[idx], lon

def get_hora_label(dt: datetime) -> str:
    """Approximate planetary Hora from sunrise-based planetary hour blocks."""
    # A practical local-time approximation: 12 daytime and 12 nighttime hours.
    # For exact traditional Hora, location and true sunrise/sunset are required.
    weekday_lord = DAY_LORDS[dt.weekday()]
    start_idx = PLANET_ORDER.index(weekday_lord)
    # Divide the 24-hour civil day into 24 equal blocks as a fallback approximation.
    # The report labels it approximate so it is not confused with a precise sunrise Hora.
    block = dt.hour
    return PLANET_ORDER[(start_idx + block) % len(PLANET_ORDER)] + " Hora (approx.)"

def indicators(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d = d.dropna(subset=["Open", "High", "Low", "Close", "Volume"])
    if d.empty:
        return d
    close, high, low, vol = d["Close"], d["High"], d["Low"], d["Volume"]
    typical = (high + low + close) / 3
    d["VWAP"] = (typical * vol).cumsum() / vol.replace(0, np.nan).cumsum()
    d["EMA20"] = close.ewm(span=20, adjust=False).mean()
    d["EMA50"] = close.ewm(span=50, adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    d["RSI"] = 100 - (100 / (1 + rs))
    tr = pd.concat([
        high - low, (high - close.shift()).abs(), (low - close.shift()).abs()
    ], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1/14, adjust=False).mean()
    plus_dm = high.diff()
    minus_dm = -low.diff()
    plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0.0)
    minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0.0)
    plus_di = 100 * plus_dm.ewm(alpha=1/14, adjust=False).mean() / atr.replace(0, np.nan)
    minus_di = 100 * minus_dm.ewm(alpha=1/14, adjust=False).mean() / atr.replace(0, np.nan)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    d["ADX"] = dx.ewm(alpha=1/14, adjust=False).mean()
    # RVOL compares current bar volume with prior 20-bar mean (no look-ahead).
    d["RVOL"] = vol / vol.shift(1).rolling(20, min_periods=5).mean()
    return d

def candle_patterns(d: pd.DataFrame) -> list[str]:
    if len(d) < 4:
        return []
    a, b, c, last = [d.iloc[i] for i in range(-4, 0)]
    found = []
    # Bullish engulfing: prior red body, current green body envelops it.
    if (b.Close < b.Open and last.Close > last.Open and
        last.Open <= b.Close and last.Close >= b.Open):
        found.append("Bullish Engulfing")
    # Three White Soldiers (simple candle-body approximation).
    if all(x.Close > x.Open for x in [b, c, last]) and b.Close < c.Close < last.Close:
        found.append("Three White Soldiers")
    # Inside bar
    if last.High < c.High and last.Low > c.Low:
        found.append("Inside Bar")
    # Rising Three is approximated, not a strict textbook classifier.
    if b.Close > b.Open and c.Low > b.Low and last.Close > c.Close:
        found.append("Rising Three (approx.)")
    # Spinning top: small real body vs full range.
    rng = max(float(last.High - last.Low), 1e-9)
    if abs(float(last.Close - last.Open)) / rng <= 0.25:
        found.append("Spinning Top")
    # Piercing line
    mid_b = (float(b.Open) + float(b.Close)) / 2
    if b.Close < b.Open and last.Close > last.Open and last.Open < b.Close and last.Close > mid_b and last.Close < b.Open:
        found.append("Piercing Line")
    return found

def score_symbol(symbol: str, nakshatra: str, hora: str) -> dict | None:
    ticker = symbol + ".NS"
    try:
        raw = yf.download(ticker, period="5d", interval="5m", progress=False,
                          auto_adjust=False, threads=False)
        if raw is None or raw.empty:
            return None
        if isinstance(raw.columns, pd.MultiIndex):
            raw.columns = raw.columns.get_level_values(0)
        raw = raw.rename(columns={c: str(c).title() for c in raw.columns})
        needed = ["Open", "High", "Low", "Close", "Volume"]
        if not all(c in raw.columns for c in needed):
            return None
        d = indicators(raw[needed].dropna())
        if len(d) < 30:
            return None
        last = d.iloc[-1]
        recent = d.tail(75)
        # ORB uses today's first 3 five-minute bars, if today's bars exist.
        local_dates = pd.to_datetime(d.index).date
        today_mask = np.array([x == now_ist().date() for x in local_dates])
        today = d.loc[today_mask]
        if len(today) >= 3:
            orb_high = float(today["High"].iloc[:3].max())
            orb_low = float(today["Low"].iloc[:3].min())
        else:
            # Clearly label fallback values; do not claim today's ORB is confirmed.
            orb_high = float("nan")
            orb_low = float("nan")
        price = float(last.Close)
        vwap = float(last.VWAP) if pd.notna(last.VWAP) else float("nan")
        ema20 = float(last.EMA20) if pd.notna(last.EMA20) else float("nan")
        ema50 = float(last.EMA50) if pd.notna(last.EMA50) else float("nan")
        rsi = float(last.RSI) if pd.notna(last.RSI) else float("nan")
        adx = float(last.ADX) if pd.notna(last.ADX) else float("nan")
        rvol = float(last.RVOL) if pd.notna(last.RVOL) else float("nan")
        patterns = candle_patterns(d)
        bull = 0
        bear = 0
        if pd.notna(vwap):
            bull += 15 if price > vwap else 0
            bear += 15 if price < vwap else 0
        if pd.notna(orb_high) and price > orb_high:
            bull += 10
        if pd.notna(orb_low) and price < orb_low:
            bear += 10
        if pd.notna(ema20) and pd.notna(ema50):
            bull += 15 if ema20 > ema50 else 0
            bear += 15 if ema20 < ema50 else 0
        if pd.notna(rsi):
            bull += 10 if rsi > 55 else 0
            bear += 10 if rsi < 45 else 0
        if pd.notna(adx) and adx >= 20:
            bull += 10 if price > ema20 else 0
            bear += 10 if price < ema20 else 0
        if pd.notna(rvol) and rvol >= 1.5:
            bull += 15 if price >= float(last.Open) else 0
            bear += 15 if price < float(last.Open) else 0
        bull_patterns = {"Bullish Engulfing", "Three White Soldiers", "Piercing Line", "Rising Three (approx.)"}
        if any(p in bull_patterns for p in patterns):
            bull += 10
        # Bearish score is technical short-side mirror; patterns from image are not bearish mappings.
        change = (price / float(d["Close"].iloc[-2]) - 1) * 100
        mapped = NAKSHATRA_PATTERNS.get(nakshatra, [])
        astro_match = [p for p in patterns if p in mapped]
        return {
            "symbol": symbol, "price": round(price, 2), "change_pct": round(change, 2),
            "bull_score": min(bull, 100), "bear_score": min(bear, 100),
            "vwap": round(vwap, 2) if pd.notna(vwap) else None,
            "ema20": round(ema20, 2) if pd.notna(ema20) else None,
            "ema50": round(ema50, 2) if pd.notna(ema50) else None,
            "rsi": round(rsi, 1) if pd.notna(rsi) else None,
            "adx": round(adx, 1) if pd.notna(adx) else None,
            "rvol": round(rvol, 2) if pd.notna(rvol) else None,
            "orb": "Confirmed breakout" if pd.notna(orb_high) and price > orb_high else
                   "Confirmed breakdown" if pd.notna(orb_low) and price < orb_low else
                   "Unavailable/not triggered",
            "patterns": ", ".join(patterns) if patterns else "None detected",
            "astro_pattern_match": ", ".join(astro_match) if astro_match else "No mapped match",
            "nakshatra": nakshatra, "hora": hora,
            "futures_oi": "UNAVAILABLE - no permitted provider configured",
            "option_chain": "UNAVAILABLE - no permitted provider configured",
            "sector_confirmation": "Not calculated in free starter",
            "data_source": "Yahoo Finance public endpoint; not official NSE; verify freshness",
        }
    except Exception as exc:
        print(f"[WARN] {symbol}: {type(exc).__name__}: {exc}")
        return None

def fmt(value, suffix=""):
    return "—" if value is None or (isinstance(value, float) and math.isnan(value)) else f"{value}{suffix}"

def write_reports(rows: list[dict], now: datetime, nakshatra: str, hora: str):
    REPORTS.mkdir(exist_ok=True)
    df = pd.DataFrame(rows)
    csv_path = REPORTS / "scan_latest.csv"
    md_path = REPORTS / "scan_latest.md"
    df.to_csv(csv_path, index=False)
    bulls = sorted([r for r in rows if r["bull_score"] >= MIN_SCORE],
                   key=lambda x: x["bull_score"], reverse=True)[:3]
    bears = sorted([r for r in rows if r["bear_score"] >= MIN_SCORE],
                   key=lambda x: x["bear_score"], reverse=True)[:3]
    lines = [
        "# NSE Astro + Smart Money Scanner",
        f"- Scan time: **{now.strftime('%Y-%m-%d %H:%M:%S %Z')}**",
        f"- Moon Nakshatra: **{nakshatra}**",
        f"- Hora: **{hora}**",
        "- Mode: **watchlist only; no orders placed**",
        "- Data: Yahoo Finance public endpoint; not an official NSE feed. Check freshness.",
        "- Futures OI, option chain and sector confirmation: **not configured/unconfirmed**.",
        "",
        "> Astrology is experimental and not a validated predictor. Verify prices and signals.",
        "",
        "## Top 3 bullish candidates",
    ]
    if not bulls:
        lines.append("No candidates met the minimum bullish score.")
    for i, r in enumerate(bulls, 1):
        lines += [
            f"### {i}. {r['symbol']} — score {r['bull_score']}/100",
            f"- Price: {fmt(r['price'])} | change: {fmt(r['change_pct'], '%')}",
            f"- VWAP: {fmt(r['vwap'])} | EMA20/50: {fmt(r['ema20'])}/{fmt(r['ema50'])}",
            f"- RSI: {fmt(r['rsi'])} | ADX: {fmt(r['adx'])} | RVOL: {fmt(r['rvol'])}",
            f"- ORB: {r['orb']} | Patterns: {r['patterns']}",
            f"- Nakshatra mapping: {r['astro_pattern_match']} ({r['nakshatra']})",
            "- Futures OI: unconfirmed | Option chain: unconfirmed | Sector: unconfirmed",
            "",
        ]
    lines.append("## Top 3 bearish candidates")
    if not bears:
        lines.append("No candidates met the minimum bearish score.")
    for i, r in enumerate(bears, 1):
        lines += [
            f"### {i}. {r['symbol']} — score {r['bear_score']}/100",
            f"- Price: {fmt(r['price'])} | change: {fmt(r['change_pct'], '%')}",
            f"- VWAP: {fmt(r['vwap'])} | EMA20/50: {fmt(r['ema20'])}/{fmt(r['ema50'])}",
            f"- RSI: {fmt(r['rsi'])} | ADX: {fmt(r['adx'])} | RVOL: {fmt(r['rvol'])}",
            f"- ORB: {r['orb']} | Patterns: {r['patterns']}",
            f"- Nakshatra mapping: {r['astro_pattern_match']} ({r['nakshatra']})",
            "- Futures OI: unconfirmed | Option chain: unconfirmed | Sector: unconfirmed",
            "",
        ]
    lines += [
        "## Data and risk notes",
        "- Entry/stop/target are intentionally not fabricated. Add a tested risk model before use.",
        "- No data row means the public provider returned no usable 5-minute candles.",
        "- A minimum score is a ranking threshold, not a probability of success.",
        "- Check `symbols.txt` and update it against the current F&O list.",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[:20]))
    print(f"\nWrote {csv_path} and {md_path}")

def main():
    now = now_ist()
    print(f"Scanner started: {now.isoformat()}")
    # A manual workflow_dispatch can be run any time, but it still avoids claiming
    # intraday signals outside market hours. It writes an explanatory report.
    if not market_is_open_window(now):
        print("Outside NSE weekday market window or configured holiday. Writing status report.")
    try:
        nakshatra, moon_lon = get_moon_nakshatra(now)
        hora = get_hora_label(now)
    except Exception as exc:
        print(f"Astronomy calculation unavailable: {exc}")
        nakshatra, hora, moon_lon = "Unavailable", "Unavailable", float("nan")
    symbols = load_symbols()
    rows = []
    if market_is_open_window(now):
        for i, symbol in enumerate(symbols, 1):
            print(f"[{i}/{len(symbols)}] Fetching {symbol}")
            row = score_symbol(symbol, nakshatra, hora)
            if row:
                rows.append(row)
    write_reports(rows, now, nakshatra, hora)
    print(f"Processed {len(rows)} symbols. Moon longitude: {moon_lon:.2f}°" if not math.isnan(moon_lon)
          else f"Processed {len(rows)} symbols.")

if __name__ == "__main__":
    main()
